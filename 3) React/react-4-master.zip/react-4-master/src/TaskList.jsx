import React from 'react';
import { uniqueId } from 'lodash';

// TaskList component
export default class TaskList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      tasks: [
        {
          id: uniqueId(), title: 'Learn React', body: 'I should learn react', state: 'current',
        },
        {
          id: uniqueId(), title: 'Learn JS', body: 'Yay!', state: 'finished',
        },
        {
          id: uniqueId(), title: 'Learn HTML', body: 'DONE!', state: 'finished',
        },
        {
          id: uniqueId(), title: 'Learn Redux', body: 'Should learn after React', state: 'current',
        },
      ],
    };
  }
}
