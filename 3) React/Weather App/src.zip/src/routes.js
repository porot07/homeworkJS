const host = 'https://api.openweathermap.org/data/2.5/';

export default {
  current: () => [host, 'weather'].join('/'),
  forecast: () => [host, 'forecast'].join('/'),
};
