import axios from 'axios';
import routes from '../routes';

const getWeatherData = async (id) => {
  const response = await axios.get(routes.current(), {
    params: {
      id,
      appid: 'ce488d53cd521bde797eb76b70e9fa0c',
    },
  });
  const { data } = response;
  return data;
};

export default getWeatherData;
