import React from 'react';
import { Field, reduxForm } from 'react-form';

const Form = (props) => {
  const { handleSubmit } = props;
  return (
    <form onSubmit={handleSubmit}>
      <Field type="text" component="input" name="city" />
      <button type="submit">Get Weather</button>
    </form>
  );
};

export default reduxForm({
  form: 'city',
})(Form);
