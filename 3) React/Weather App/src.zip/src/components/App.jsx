import React from 'react';
import getWeatherData from '../actions';
// import axios from 'axios';
// import routes from '../routes';


const App = () => {
//   const data2 = async () => {
//     const response = await axios.get(routes.current(), {
//       params: {
//         id: 1484839,
//         appid: 'ce488d53cd521bde797eb76b70e9fa0c',
//       },
//     });

//     const { data } = response;
//     console.log(data);
//     return response;
//   };
//   data2();
  const data = getWeatherData();
  console.log(data);
  return (
    <div>
      <button type="buton">Click me</button>
    </div>
  );
};

export default App;
