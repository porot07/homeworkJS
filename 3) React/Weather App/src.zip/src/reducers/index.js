// import { handleActions } from 'redux-actions';
// import { combineReducers } from 'redux';
// import * as actions from '../actions';
// import routes from '../routes';

// const data = handleActions({
//   [actions.weatherGetData](state, { payload: { id } }) {


//     return {
//       ...state,
//       ...getObjectData,
//     },
//   },
// }, {});

// export default combineReducers({
//   data,
// });
