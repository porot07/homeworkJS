const state = {
  posts: {},
  post: {},
  users: {},
};

export default state;
