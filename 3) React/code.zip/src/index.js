import app from './app';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap';

app();
