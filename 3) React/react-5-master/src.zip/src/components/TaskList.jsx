import React from 'react';

export default class TaskList extends React.Component {
  render() {
    return (
      <div className="col-3">
        <div className="card m-2 text-white bg-primary">
          <div className="card-header">
            <h3 className="card-title">{this.props.title}</h3>
          </div>
          <div className="card-body">
            <p className="card-text">{this.props.body}</p>
          </div>
          <div className="card-footer">
            <button type="button" className="btn btn-outline-light">Завершить задачу</button>
          </div>
        </div>
      </div>
    );
  }
}
