import React from 'react';
import { uniqueId } from 'lodash';
import TaskForm from './TaskForm';
import TaskList from './TaskList';

export default class TaskContainer extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      taskList: [],
      titleValue: '',
      bodyValue: '',
    };
  }

  addTask = () => {
    this.setState({
      taskList: [<TaskList
                  body={this.state.bodyValue}
                  title={this.state.titleValue}
                  key={uniqueId}
                />, ...this.state.taskList],
    });
    console.log(this.state.taskList);
  }

  onSubmit = (e) => {
    e.preventDefault();
  }

  changeTitle = (e) => {
    e.preventDefault();
    this.setState({
      titleValue: e.target.value,
    });
  }

  changeBody = (e) => {
    e.preventDefault();
    this.setState({
      bodyValue: e.target.value,
    });
  }

  render() {
    return (
      <div className="row">
        <div className="col-12">
          <TaskForm
          onSubmit={this.onSubmit}
          onChangeBody={this.changeBody}
          onChangeTitle={this.changeTitle}
          addTask={this.addTask} />
        </div>
        <div className="col-12">
          <div className="row">
            {this.state.taskList}
          </div>
        </div>
      </div>
    );
  }
}
