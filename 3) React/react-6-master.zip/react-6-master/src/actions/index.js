export const addPost = (post) => {};

export const removePost = (id) => {};

export const addPostComment = (comment) => {};

export const removePostComment = (id) => {};
