import React from 'react';
import { connect } from 'react-redux';

class TaskForm extends React.Component {

}

const mapStateToProps = (state) => ({
  
});

export default connect(mapStateToProps, actions)(TaskForm);
