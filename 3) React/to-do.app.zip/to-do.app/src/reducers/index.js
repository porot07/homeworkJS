import { handleActions } from 'redux-actions';
import { combineReducers } from 'redux';
