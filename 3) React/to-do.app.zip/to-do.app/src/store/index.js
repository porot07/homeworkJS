import { createStore } from 'redux';

export default () => {
  const reducer = () => {

  }

  return createStore(reducer);
};
