import React from 'react';
import { reduxForm } from 'redux-form';
import Form from './Form';

const FormAddTaskContainer = (props) => (
  <Form {...props} />
);

export default reduxForm({
  form: 'editTask',
  // enableReinitialize: true,
})(FormAddTaskContainer);
