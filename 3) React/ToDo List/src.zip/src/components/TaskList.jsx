import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { enterEditMode, editTask } from '../actions';
import FormEditTaskContainer from './FormEditTaskContainer';

const TaskContainer = ({ task }) => {
  const dispatch = useDispatch();

  const handleClickChangeMode = () => {
    dispatch(enterEditMode({ id: task.id }));
  };

  return (
    <>
      <div className="task-list-title">{task.title}</div>
      <div className="task-list-body">{task.body}</div>
      <button type="button" onClick={handleClickChangeMode}>Редактировать</button>
    </>
  );
};

const TaskList = () => {
  const tasks = useSelector((state) => Object.values(state.tasks));

  const dispatch = useDispatch();

  const handleEditTask = (id) => (formValues) => {
    dispatch(editTask({
      task: {
        ...formValues,
        id,
      },
    }));
  };

  return (
    <div className="tasks">
      <h1 className="task-title" />
      <div className="tasks-filter" />
      <div className="tasks-list">
        {tasks.map((task) => (
          <div key={task.id} className="tasks-list-item">
            {task.isEditMode
              ? <FormEditTaskContainer submitTaskForm={handleEditTask(task.id)} className="edit-task" initialValues={task} />
              : <TaskContainer task={task} />
            }
          </div>
        ))}
      </div>
    </div>
  );
};

export default TaskList;
