import 'bootstrap/dist/css/bootstrap.min.css';
import './css/style.css';
import app from './app';

app();
