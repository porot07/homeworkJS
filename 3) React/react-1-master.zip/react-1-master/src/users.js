export default [
  {
    name: 'Jon',
    info: {
      age: 20,
      email: 'jon@winter.com',
    },
  },
  {
    name: 'Daenerys',
    info: {
      age: 19,
      email: 'daenerys@dragons.com',
    },
  },
  {
    name: 'Eddard',
    info: {
      age: 45,
      email: 'eddard@winter.com',
    },
  },
  {
    name: 'Cersei',
    info: {
      age: 35,
      email: 'cersei@shame.com',
    },
  },
];
